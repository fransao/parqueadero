package parqueadero.unitaria;

import static org.junit.Assert.*;

import org.junit.Test;

import parqueadero.dominio.Moto;
import testdatabuilder.MotoTestDataBuilder;

public class ParqueaderoTest {


}
