package parqueadero.ws.servicecontroller;

public class VehiculoController {

}
