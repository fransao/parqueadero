package parqueadero.repositorio;

import org.springframework.stereotype.Repository;

import parqueadero.dominio.Vehiculo;

@Repository
public class RepositorioVehiculo {

    public void registrarPlacaVehiculo(Vehiculo vehiculo) {
        // TODO Auto-generated method stub
        
    }
}